// Smooth Scrolling
document.querySelectorAll('nav a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();

        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Animations on Scroll
const faders = document.querySelectorAll('.fadeIn');
const sliders = document.querySelectorAll('.slideIn');

const appearOptions = {
    threshold: 0,
    rootMargin: "0px 0px -100px 0px"
};

const appearOnScroll = new IntersectionObserver(function(
    entries,
    appearOnScroll
) {
    entries.forEach(entry => {
        if (!entry.isIntersecting) {
            return;
        } else {
            entry.target.classList.add('appear');
            appearOnScroll.unobserve(entry.target);
        }
    });
}, appearOptions);

faders.forEach(fader => {
    appearOnScroll.observe(fader);
});

sliders.forEach(slider => {
    appearOnScroll.observe(slider);
});

// Contact form validation
const contactForm = document.querySelector('form');
contactForm.addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();
    
    // Simple email validation regex
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    
    let valid = true;

    // Reset previous error styles
    document.querySelectorAll('form input, form textarea').forEach(input => input.style.borderColor = '#ced4da');

    if (name === "") {
        valid = false;
        document.getElementById('name').style.borderColor = 'red';
    }

    if (email === "" || !emailRegex.test(email)) {
        valid = false;
        document.getElementById('email').style.borderColor = 'red';
    }

    if (message === "") {
        valid = false;
        document.getElementById('message').style.borderColor = 'red';
    }

    if (!valid) {
        alert("Please fill in all fields correctly.");
    } else {
        alert("Thank you for your message!");
        contactForm.reset();
    }
});
// Travel Tips cycling effect
const tips = [
    "Packing essentials for any trip.",
    "Safety tips for solo travelers.",
    "Budget-friendly travel ideas.",
    "How to avoid common travel scams.",
    "The best travel apps for your journey.",
    "How to deal with jet lag.",
    "Must-try local foods around the world."
];

let tipIndex = 0;  // Keeps track of the current tip

function changeTip() {
    const tipTextElement = document.getElementById("tipText");
    const tipBox = document.getElementById("tipBox");

    // Fade out the tip box
    tipBox.classList.remove('visible');

    // Wait for the fade-out to complete, then change the tip text
    setTimeout(() => {
        tipTextElement.textContent = tips[tipIndex];
        tipBox.classList.add('visible');

        // Update the tip index and cycle back to 0 if we've reached the end
        tipIndex = (tipIndex + 1) % tips.length;
    }, 600); // Timeout matches the fade-out transition duration
}

// Initial call to display the first tip
changeTip();

// Change the tip every 4 seconds (4000 milliseconds)
setInterval(changeTip, 4000);
// Function to fetch search results from the API based on user input
